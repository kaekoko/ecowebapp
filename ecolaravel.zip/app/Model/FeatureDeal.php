<?php

namespace App\Model;

use App\CPU\Helpers;
use Illuminate\Database\Eloquent\Model;

class FeatureDeal extends Model
{
    //
}
