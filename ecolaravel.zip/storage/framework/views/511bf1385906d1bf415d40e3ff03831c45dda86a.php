<?php if(isset($folder) && session($folder)!=null): ?>
    <?php $__currentLoopData = session($folder); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4" style="margin-bottom: 10px">
            <?php ($data = getimagesize($i['image'])); ?>
            <img width="<?php echo e($data[0]/3); ?>" height="<?php echo e($data[1]/3); ?>" src="<?php echo e($i['image']); ?>"/>
            <div style="width: <?php echo e($data[0]/3); ?>px; background-color: white ">
                <a onclick="removeImage('<?php echo e($i['remove_route']); ?>'+'/'+'<?php echo e($k); ?>'+'/'+'<?php echo e($folder); ?>','<?php echo e($modal_id); ?>')"
                   href="javascript:" class="call-when-done">
                    <center style="color: #ff6161">
                        <i class="fa fa-trash"></i>
                    </center>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/ecommerce/resources/views/shared-partials/image-process/_show-images.blade.php ENDPATH**/ ?>