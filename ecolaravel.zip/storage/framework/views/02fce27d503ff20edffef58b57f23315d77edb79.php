<?php $__env->startSection('title','Order Details'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <style>
        @media (max-width: 500px) {
            .product-name {
                display: none;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header d-print-none" style="padding-bottom: 10px;margin-bottom: 10px">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-no-gutter">
                            <li class="breadcrumb-item"><a class="breadcrumb-link"
                                                           href="<?php echo e(route('admin.orders.list',['status'=>'all'])); ?>"><?php echo e(trans('messages.Orders')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"
                                aria-current="page"><?php echo e(trans('messages.Order')); ?> <?php echo e(trans('messages.details')); ?> </li>
                        </ol>
                    </nav>

                    <div class="d-sm-flex align-items-sm-center">
                        <h1 class="page-header-title"><?php echo e(trans('messages.Order')); ?> #<?php echo e($order['id']); ?></h1>

                        <?php if($order['payment_status']=='paid'): ?>
                            <span class="badge badge-soft-success ml-sm-3">
                                <span class="legend-indicator bg-success"></span><?php echo e(trans('messages.Paid')); ?>

                            </span>
                        <?php else: ?>
                            <span class="badge badge-soft-danger ml-sm-3">
                                <span class="legend-indicator bg-danger"></span><?php echo e(trans('messages.Unpaid')); ?>

                            </span>
                        <?php endif; ?>

                        <?php if($order['order_status']=='pending'): ?>
                            <span class="badge badge-soft-info ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-info text"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>
                        <?php elseif($order['order_status']=='failed'): ?>
                            <span class="badge badge-danger ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-info"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>
                        <?php elseif($order['order_status']=='processing'): ?>
                            <span class="badge badge-soft-warning ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-warning"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>

                        <?php elseif($order['order_status']=='delivered'): ?>
                            <span class="badge badge-soft-success ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-success"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>
                        <?php else: ?>
                            <span class="badge badge-soft-danger ml-2 ml-sm-3 text-capitalize">
                              <span class="legend-indicator bg-danger"></span><?php echo e(str_replace('_',' ',$order['order_status'])); ?>

                            </span>
                        <?php endif; ?>
                        <span class="ml-2 ml-sm-3">
                        <i class="tio-date-range"></i> <?php echo e(date('d M Y H:i:s',strtotime($order['created_at']))); ?>

                </span>
                    </div>
                    <div class="col-md-6 mt-2">
                        <a class="text-body mr-3" target="_blank"
                           href=<?php echo e(route('admin.orders.generate-invoice',[$order['id']])); ?>>
                            <i class="tio-print mr-1"></i> <?php echo e(trans('messages.Print')); ?> <?php echo e(trans('messages.invoice')); ?>

                        </a>
                    </div>

                    <!-- Unfold -->

                    <div class="hs-unfold float-right">
                        <div class="dropdown">
                            <select name="order_status" class="status form-control" data-id="<?php echo e($order['id']); ?>">

                                <option
                                    value="pending" <?php echo e($order->order_status == 'pending'?'selected':''); ?> > <?php echo e(trans('messages.Pending')); ?></option>
                                <option
                                    value="processed" <?php echo e($order->order_status == 'processed'?'selected':''); ?> ><?php echo e(trans('messages.Processing')); ?> </option>
                                <option
                                    value="delivered" <?php echo e($order->order_status == 'delivered'?'selected':''); ?> ><?php echo e(trans('messages.Delivered')); ?> </option>
                                <option
                                    value="returned" <?php echo e($order->order_status == 'returned'?'selected':''); ?> > <?php echo e(trans('messages.Returned')); ?></option>
                                <option
                                    value="failed" <?php echo e($order->order_status == 'failed'?'selected':''); ?> ><?php echo e(trans('messages.Failed')); ?> </option>
                            </select>
                        </div>
                    </div>
                    <div class="hs-unfold float-right pr-2">
                        <div class="dropdown">
                            <select name="payment_status" class="payment_status form-control"
                                    data-id="<?php echo e($order['id']); ?>">

                                <option
                                    onclick="route_alert('<?php echo e(route('admin.orders.payment-status',['id'=>$order['id'],'payment_status'=>'paid'])); ?>','Change status to paid ?')"
                                    href="javascript:" value="paid" <?php echo e($order->payment_status == 'paid'?'selected':''); ?> >
                                    <?php echo e(trans('messages.Paid')); ?>

                                </option>
                                <option value="unpaid" <?php echo e($order->payment_status == 'unpaid'?'selected':''); ?> >
                                    <?php echo e(trans('messages.Unpaid')); ?>

                                </option>

                            </select>
                        </div>
                    </div>
                    <!-- End Unfold -->
                </div>
            </div>
        </div>

        <!-- End Page Header -->

        <div class="row" id="printableArea">
            <div class="col-lg-8 mb-3 mb-lg-0">
                <!-- Card -->
                <div class="card mb-3 mb-lg-5">
                    <!-- Header -->
                    <div class="card-header" style="display: block!important;">
                        <div class="row">
                            <div class="col-12 pb-2 border-bottom">
                                <h4 class="card-header-title">
                                    <?php echo e(trans('messages.Order')); ?> <?php echo e(trans('messages.details')); ?>

                                    <span
                                        class="badge badge-soft-dark rounded-circle ml-1"><?php echo e($order->details->count()); ?></span>
                                </h4>
                            </div>
                            <div class="col-6 pt-2">

                            </div>
                            <div class="col-6 pt-2">
                                <div class="text-right">
                                    <h6 class="" style="color: #8a8a8a;">
                                        <?php echo e(trans('messages.Payment')); ?> <?php echo e(trans('messages.Method')); ?>

                                        : <?php echo e(str_replace('_',' ',$order['payment_method'])); ?>

                                    </h6>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Header -->

                    <!-- Body -->
                    <div class="card-body">
                        <div class="media">
                            <div class="avatar avatar-xl mr-3">
                                <p><?php echo e(trans('messages.image')); ?></p>
                            </div>

                            <div class="media-body">
                                <div class="row">
                                    <div class="col-md-3 product-name">
                                        <p> <?php echo e(trans('messages.Name')); ?></p>
                                    </div>

                                    <div class="col col-md-1 align-self-center p-0 ">
                                        <p> <?php echo e(trans('messages.price')); ?></p>
                                    </div>

                                    <div class="col col-md-1 align-self-center">
                                        <p>Q</p>
                                    </div>
                                    <div class="col col-md-1 align-self-center  p-0 product-name">
                                        <p> <?php echo e(trans('messages.TAX')); ?></p>
                                    </div>
                                    <div class="col col-md-2 align-self-center  p-0 product-name">
                                        <p> <?php echo e(trans('messages.Discount')); ?></p>
                                    </div>
                                    <div class="col col-md-2 align-self-center  p-0">
                                        <p> <?php echo e(trans('messages.Status')); ?></p>
                                    </div>

                                    <div class="col col-md-2 align-self-center text-right  ">
                                        <p> <?php echo e(trans('messages.Subtotal')); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php ($subtotal=0); ?>
                    <?php ($total=0); ?>
                    <?php ($shipping=0); ?>
                    <?php ($discount=0); ?>
                    <?php ($tax=0); ?>

                    <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->product): ?>

                            <!-- Media -->
                                <div class="media">
                                    <div class="avatar avatar-xl mr-3">
                                        <img class="img-fluid"
                                             onerror="this.src='<?php echo e(asset('public/assets/back-end/img/160x160/img2.jpg')); ?>'"
                                             src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($detail->product['thumbnail']); ?>"
                                             alt="Image Description">
                                    </div>

                                    <div class="media-body">
                                        <div class="row">
                                            <div class="col-md-3 mb-3 mb-md-0 product-name">
                                                <p> 
                                                    <?php echo e(substr($detail->product['name'],0,10)); ?><?php echo e(strlen($detail->product['name'])>10?'...':''); ?></p>
                                                <strong><u><?php echo e(trans('messages.Variation')); ?> : </u></strong>

                                                <div class="font-size-sm text-body">

                                                    <span class="font-weight-bold"><?php echo e($detail['variant']); ?></span>
                                                </div>
                                            </div>

                                            <div class="col col-md-1 align-self-center p-0 ">
                                                <h6><?php echo e(\App\CPU\BackEndHelper::usd_to_currency($detail['price'])); ?></h6>
                                            </div>

                                            <div class="col col-md-1 align-self-center">

                                                <h5><?php echo e($detail->qty); ?></h5>
                                            </div>
                                            <div class="col col-md-1 align-self-center  p-0 product-name">

                                                <h5><?php echo e(\App\CPU\BackEndHelper::usd_to_currency($detail['tax'])); ?></h5>
                                            </div>
                                            <div class="col col-md-2 align-self-center  p-0 product-name">

                                                <h5>
                                                    - <?php echo e(\App\CPU\BackEndHelper::usd_to_currency($detail['discount'])); ?></h5>
                                            </div>
                                            <div class="col col-md-2 align-self-center  p-0">
                                                <select name="delivery_status" class="product_status form-control small"
                                                        style="padding: 0px;" data-id="<?php echo e($detail['id']); ?>">
                                                    <option
                                                        value="pending" <?php echo e($detail->delivery_status == 'pending'?'selected':''); ?> ><?php echo e(trans('messages.Pending')); ?> </option>
                                                    <option
                                                        value="processing" <?php echo e($detail->delivery_status == 'processing'?'selected':''); ?> > <?php echo e(trans('messages.Processing')); ?></option>
                                                    <option
                                                        value="delivered" <?php echo e($detail->delivery_status == 'delivered'?'selected':''); ?> ><?php echo e(trans('messages.Delivered')); ?> </option>
                                                    <option
                                                        value="returned" <?php echo e($detail->delivery_status == 'returned'?'selected':''); ?> > <?php echo e(trans('messages.Returned')); ?></option>
                                                    <option
                                                        value="failed" <?php echo e($detail->delivery_status == 'failed'?'selected':''); ?> > <?php echo e(trans('messages.Failed')); ?></option>
                                                </select>
                                            </div>

                                            <div class="col col-md-2 align-self-center text-right  ">
                                                <?php ($subtotal=$detail['price']*$detail->qty+$detail['tax']-$detail['discount']); ?>

                                                <h5 style="font-size: 12px"><?php echo e(\App\CPU\BackEndHelper::usd_to_currency($subtotal).' '.\App\CPU\BackEndHelper::currency_symbol()); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php ($discount+=$detail['discount']); ?>
                            <?php ($tax+=$detail['tax']); ?>
                            <?php ($shipping+=$detail->shipping ? $detail->shipping->cost :0); ?>

                            <?php ($total+=$subtotal); ?>
                            <!-- End Media -->
                                <hr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="row justify-content-md-end mb-3">
                            <div class="col-md-9 col-lg-8">
                                <dl class="row text-sm-right">
                                    <dt class="col-sm-6"><?php echo e(trans('messages.Shipping')); ?></dt>
                                    <dd class="col-sm-6 border-bottom">
                                        <strong><?php echo e(\App\CPU\BackEndHelper::usd_to_currency($shipping).' '.\App\CPU\BackEndHelper::currency_symbol()); ?></strong>
                                    </dd>

                                    <dt class="col-sm-6"><?php echo e(trans('messages.Total')); ?></dt>
                                    <dd class="col-sm-6">
                                        <strong><?php echo e(\App\CPU\BackEndHelper::usd_to_currency($total+$shipping).' '.\App\CPU\BackEndHelper::currency_symbol()); ?></strong>
                                    </dd>
                                </dl>
                                <!-- End Row -->
                            </div>
                        </div>
                        <!-- End Row -->
                    </div>
                    <!-- End Body -->
                </div>
                <!-- End Card -->
            </div>

            <div class="col-lg-4">
                <!-- Card -->
                <div class="card">
                    <!-- Header -->
                    <div class="card-header">
                        <h4 class="card-header-title"><?php echo e(trans('messages.Customer')); ?></h4>
                    </div>
                    <!-- End Header -->

                    <!-- Body -->
                    <?php if($order->customer): ?>
                        <div class="card-body">
                            <div class="media align-items-center" href="javascript:">
                                <div class="avatar avatar-circle mr-3">
                                    <img
                                        class="avatar-img" style="width: 75px;height: 42px"
                                        onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                        src="<?php echo e(asset('storage/app/public/profile/'.$order->customer->image)); ?>"
                                        alt="Image">
                                </div>
                                <div class="media-body">
                                <span
                                    class="text-body text-hover-primary"><?php echo e($order->customer['f_name'].' '.$order->customer['l_name']); ?></span>
                                </div>
                                <div class="media-body text-right">
                                    
                                </div>
                            </div>

                            <hr>

                            <div class="media align-items-center" href="javascript:">
                                <div class="icon icon-soft-info icon-circle mr-3">
                                    <i class="tio-shopping-basket-outlined"></i>
                                </div>
                                <div class="media-body">
                                    <span class="text-body text-hover-primary"> <?php echo e(\App\Model\Order::where('customer_id',$order['customer_id'])->count()); ?> orders</span>
                                </div>
                                <div class="media-body text-right">
                                    
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between align-items-center">
                                <h5><?php echo e(trans('messages.Contact')); ?> <?php echo e(trans('messages.info')); ?> </h5>
                            </div>

                            <ul class="list-unstyled list-unstyled-py-2">
                                <li>
                                    <i class="tio-online mr-2"></i>
                                    <?php echo e($order->customer['email']); ?>

                                </li>
                                <li>
                                    <i class="tio-android-phone-vs mr-2"></i>
                                    <?php echo e($order->customer['phone']); ?>

                                </li>
                            </ul>

                            <hr>


                            <div class="d-flex justify-content-between align-items-center">
                                <h5><?php echo e(trans('messages.shipping_address')); ?></h5>

                            </div>

                            <span class="d-block">
                                    <?php echo e(trans('messages.Name')); ?> :
                                <strong><?php echo e($order->shipping ? $order->shipping['contact_person_name'] : "empty"); ?></strong><br>
                                <?php echo e(trans('messages.City')); ?>:
                                <strong><?php echo e($order->shipping ? $order->shipping['city'] : "Empty"); ?></strong><br>
                                <?php echo e(trans('messages.zip_code')); ?> :
                                <strong><?php echo e($order->shipping ? $order->shipping['zip']  : "Empty"); ?></strong><br>
                                <?php echo e(trans('messages.Phone')); ?>:
                                <strong><?php echo e($order->shipping ? $order->shipping['phone']  : "Empty"); ?></strong>

                                </span>

                        </div>
                <?php endif; ?>
                <!-- End Body -->
                </div>
                <!-- End Card -->
            </div>
        </div>
        <!-- End Row -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>

        $(document).on('change', '.payment_status', function () {
            var id = $(this).attr("data-id");
            var value = $(this).val();
            Swal.fire({
                title: 'Are you sure Change this?',
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#377dff',
                cancelButtonColor: 'secondary',
                confirmButtonText: 'Yes, Change it!'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "<?php echo e(route('admin.orders.payment-status')); ?>",
                        method: 'POST',
                        data: {
                            "id": id,
                            "payment_status": value
                        },
                        success: function (data) {
                            toastr.success('Status Change successfully');
                            location.reload();
                        }
                    });
                }
            })
        });

        $(document).on('change', '.status', function () {
            var id = $(this).attr("data-id");
            var value = $(this).val();
            Swal.fire({
                title: 'Are you sure Change this?',
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#377dff',
                cancelButtonColor: 'secondary',
                confirmButtonText: 'Yes, Change it!'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "<?php echo e(route('admin.orders.status')); ?>",
                        method: 'POST',
                        data: {
                            "id": id,
                            "order_status": value
                        },
                        success: function (data) {
                            toastr.success('Status Change successfully');
                            location.reload();
                        }
                    });
                }
            })
        });

        $(document).on('change', '.product_status', function () {
            var id = $(this).attr("data-id");
            var value = $(this).val();
            Swal.fire({
                title: 'Are you sure Change this?',
                text: "You won't be able to revert this!",
                showCancelButton: true,
                confirmButtonColor: '#377dff',
                cancelButtonColor: 'secondary',
                confirmButtonText: 'Yes, Change it!'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "<?php echo e(route('admin.orders.productStatus')); ?>",
                        method: 'POST',
                        data: {
                            "id": id,
                            "delivery_status": value
                        },
                        success: function (data) {
                            if (data.success == 0) {
                                toastr.warning(data.message);
                            } else {
                                toastr.success('Product Status updated successfully');
                                location.reload();
                            }
                        }
                    });
                }
            })
        });
        // $(document).on('change', '.product_status', function () {
        //     var id = $(this).attr("data-id");
        //     var value = $(this).val();


        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        //         }
        //     });
        //     $.ajax({
        //         url: "<?php echo e(route('admin.orders.productStatus')); ?>",
        //         method: 'POST',
        //         data: {

        //             "id": id,
        //             "delivery_status": value
        //         },
        //         success: function (data) {
        //             if (data.success == 0) {
        //                 toastr.warning(data.message);
        //             } else {
        //                 toastr.success('Product Status updated successfully');
        //                 location.reload();
        //             }
        //         }
        //     });
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce/resources/views/admin-views/order/order-details.blade.php ENDPATH**/ ?>