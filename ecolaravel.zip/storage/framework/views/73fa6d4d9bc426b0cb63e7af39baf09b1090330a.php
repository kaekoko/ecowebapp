<?php $__env->startSection('title','Order Complete'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

        body {
            font-family: 'Montserrat', sans-serif
        }

        .card {
            border: none
        }

        .totals tr td {
            font-size: 13px
        }

        .footer span {
            font-size: 12px
        }

        .product-qty span {
            font-size: 14px;
            color: #6A6A6A;
        }

        .spanTr {
            color: <?php echo e($web_config['primary_color']); ?>;
            font-weight: 700;

        }

        .spandHeadO {
            color: #030303;
            font-weight: 500;
            font-size: 20px;

        }

        .font-name {
            font-weight: 600;
            font-size: 13px;
        }

        .amount {
            font-size: 17px;
            color: <?php echo e($web_config['primary_color']); ?>;
        }

        @media (max-width: 600px) {
            .orderId {
                margin-right: 91px;
            }

            .p-5 {
                padding: 2% !important;
            }

            .spanTr {

                font-weight: 400 !important;
                font-size: 12px;
            }

            .spandHeadO {

                font-weight: 300;
                font-size: 12px;

            }

            .table th, .table td {
                padding: 5px;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <div class="row d-flex justify-content-center">
            <div class="col-md-10 col-lg-10">
                <div class="card">
                    <?php if(auth('customer')->check()): ?>
                        <div class=" p-5">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 style="font-size: 20px; font-weight: 900"><?php echo e(trans('messages.your_order_confirm')); ?>

                                        !</h5>
                                </div>
                                <div class="col-md-6 ">
                                    <p class="float-right"><?php echo e(trans('messages.Order')); ?> <?php echo e(trans('messages.No')); ?> :
                                        <strong><?php echo e($order_id); ?></strong></p>
                                </div>
                            </div>

                            <span class="font-weight-bold d-block mt-4" style="font-size: 17px;"><?php echo e(trans('messages.Hello')); ?>, <?php echo e(auth('customer')->user()->f_name); ?></span>
                            <span>You order has been confirmed and will be shipped according to the method you selected!</span>
                            <?php ($order=\App\Model\Order::with(['details'])->where('id',$order_id)->first()); ?>

                            <div class="payment border-top mt-3 mb-3 border-bottom table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
                                    <tr style="background: #E2F0FF">
                                        <td col="3">
                                            <div class="py-2">
                                                <span
                                                    class="d-block spandHeadO"><?php echo e(trans('messages.shipping_address')); ?></span>
                                                <span class="spanTr"></span>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="product border-bottom table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
                                    <?php ($sub_total=0); ?>
                                    <?php ($total_tax=0); ?>
                                    <?php ($total_shipping_cost=0); ?>
                                    <?php ($total_discount_on_product=0); ?>
                                    <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <td width="30%">
                                                        <img
                                                            src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($detail->product->thumbnail); ?>"
                                                            onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                                            width="100">
                                                    </td>
                                                    <td width="60%">
                                                        <span
                                                            class="font-name"><?php echo e($detail->product['name']); ?>

                                                        </span>
                                                        <br>
                                                        <small>
                                                            QTY : <?php echo e($detail['qty']); ?>

                                                        </small>
                                                        <div class="product-qty">
                                                            <?php $__currentLoopData = json_decode($detail['variation'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 =>$variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="text-muted">
                                                                    <span
                                                                        class="d-block"><?php echo e($key1); ?> : <?php echo e($variation); ?> </span>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </td>
                                                </div>
                                                <div class="col-md-6">
                                                    <td width="20%">
                                                        <div class="text-right"><span
                                                                class="font-weight-bold amount"><?php echo e(\App\CPU\Helpers::currency_converter($detail['price'])); ?></span>
                                                        </div>
                                                    </td>
                                                </div>
                                            </div>
                                        </tr>
                                        <?php ($sub_total+=$detail['price']*$detail['qty']); ?>
                                        <?php ($total_tax+=$detail['tax']); ?>
                                        <?php ($total_shipping_cost+=$detail->shipping->cost); ?>
                                        <?php ($total_discount_on_product+=$detail['discount']); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="row d-flex justify-content-end">
                                <div class="col-md-5">
                                    <table class="table table-borderless">
                                        <tbody class="totals">
                                        <tr>
                                            <td>
                                                <div class="text-left">
                                                    <span class="product-qty "><?php echo e(trans('messages.Items')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right"><span><?php echo e($order->details->count()); ?></span>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="text-left"><span
                                                        class="product-qty "><?php echo e(trans('messages.Subtotal')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right">
                                                    <span><?php echo e(\App\CPU\Helpers::currency_converter($sub_total)); ?></span>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="text-left"><span
                                                        class="product-qty "><?php echo e(trans('messages.text_fee')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right">
                                                    <span><?php echo e(\App\CPU\Helpers::currency_converter($total_tax)); ?></span>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div class="text-left"><span
                                                        class="product-qty "><?php echo e(trans('messages.Shipping')); ?> <?php echo e(trans('messages.Fee')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right">
                                                    <span><?php echo e(\App\CPU\Helpers::currency_converter($total_shipping_cost)); ?></span>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div class="text-left"><span
                                                        class="product-qty "><?php echo e(trans('messages.Discount')); ?> <?php echo e(trans('messages.on_product')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right">
                                                    <span>- <?php echo e(\App\CPU\Helpers::currency_converter($total_discount_on_product)); ?></span>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div class="text-left"><span
                                                        class="product-qty "><?php echo e(trans('messages.Coupon')); ?> <?php echo e(trans('messages.Discount')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right">
                                                    <span>- <?php echo e(\App\CPU\Helpers::currency_converter($order->discount_amount)); ?></span>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr class="border-top border-bottom">
                                            <td>
                                                <div class="text-left"><span
                                                        class="font-weight-bold"><?php echo e(trans('messages.Total')); ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-right"><span
                                                        class="font-weight-bold amount "><?php echo e(\App\CPU\Helpers::currency_converter($order->order_amount)); ?></span>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <p> <?php echo e(trans('messages.shipping_confirmation_email')); ?>!</p>

                            <p class="font-weight-bold mb-2"><?php echo e(trans('messages.thanks_for_shopping_with')); ?>!</p>
                            <br>

                            <div class="row">
                                
                                <div class="col-6">
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">
                                        <?php echo e(trans('messages.go_to_shopping')); ?>

                                    </a>
                                </div>

                                <div class="col-6">
                                    <a href="<?php echo e(route('track-order.last')); ?>" class="btn btn-secondary pull-right">
                                        <?php echo e(trans('messages.Track')); ?> <?php echo e(trans('messages.Order')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <center>
                            <h5>Order Complete</h5>
                        </center>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce/resources/views/web-views/checkout-complete.blade.php ENDPATH**/ ?>