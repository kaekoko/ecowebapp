

<div class="footer">
    <div class="row justify-content-between align-items-center">
        <div class="col">
            
        </div>
        <div class="col-auto">
            <div class="d-flex justify-content-end">
                <!-- List Dot -->
                <ul class="list-inline list-separator">
                    <span>Copyright &copy; Your Website 2020</span>
                  
                </ul>
                <!-- End List Dot -->
            </div>
        </div>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/ecommerce/resources/views/layouts/back-end/partials-seller/_footer.blade.php ENDPATH**/ ?>