<?php $__env->startSection('title','Review Order'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <style>
        .stripe-button-el {
            display: none !important;
        }
        .razorpay-payment-button{
            display: none!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Content-->
    <div class="container pb-5 mb-2 mb-md-4">
        <div class="row">
            <div class="col-md-12 mb-5 pt-5">
                <div class="feature_header" style="background: #dcdcdc;line-height: 1px">
                    <span><?php echo e(trans('messages.checkout_review')); ?></span>
                </div>
            </div>
            <section class="col-lg-8">
                <hr>
                <div class="checkout_details mt-3">
                <?php echo $__env->make('web-views.partials._checkout-steps',['step'=>4], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Order details-->
                    <h2 class="h6 pt-1 pb-3 mb-3 mt-5"><?php echo e(trans('messages.review_your_order')); ?></h2>
                    <!-- Item-->
                    <?php $__currentLoopData = \App\CPU\CartManager::get_cart(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $products = \App\CPU\ProductManager::get_product($cart['id']);
                        ?>
                        <div class="d-sm-flex justify-content-between align-items-center my-4 pb-3 border-bottom">

                            <div
                                class="media media-ie-fix d-block d-sm-flex align-items-center text-center text-sm-left">
                                <a
                                    class="d-inline-block mx-auto mr-sm-4" href="javascript:" style="width: 10rem;">
                                    <img
                                        onerror="this.src='<?php echo e(asset('public/assets/front-end/img/image-place-holder.png')); ?>'"
                                        src="<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail')); ?>/<?php echo e($products['thumbnail']); ?>"
                                        alt="Product"></a>
                                <div class="media-body pt-2">
                                    <h3 class="product-title font-size-base mb-2">
                                        <a href="javascript:"><?php echo e($products['name']); ?></a>
                                    </h3>
                                    <small>
                                        QTY : <?php echo e($cart['quantity']); ?>

                                    </small>
                                    <?php $__currentLoopData = $cart['variations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 =>$variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="font-size-sm"><span
                                                class="text-muted mr-2"><?php echo e($key1); ?> :</span><?php echo e($variation); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div
                                        class=" text-accent"><?php echo e(\App\CPU\Helpers::currency_converter($cart['price']-$cart['discount'])); ?></div>
                                    <?php if($cart['discount'] > 0): ?>
                                        <strike style="font-size: 12px!important;color: grey!important;">
                                            <?php echo e(\App\CPU\Helpers::currency_converter($cart['price'])); ?>

                                        </strike>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Item-->
                    <!-- Client details-->
                    <div class="bg-secondary rounded-lg px-4 pt-4 pb-2">
                        <div class="row">
                            <div class="col-sm-6">
                                <h4 class="h6"><?php echo e(trans('messages.Ship')); ?> <?php echo e(trans('messages.to')); ?> :</h4>
                                <?php ($data=session('customer_info')); ?>
                                <?php ($address=\App\Model\ShippingAddress::find($data['address_id'])); ?>
                                <?php if(isset($address)): ?>
                                    <ul class="list-unstyled font-size-sm">
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.Client')); ?>:&nbsp;</span><?php echo e($address['contact_person_name']); ?>

                                        </li>
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.address')); ?>:&nbsp;</span><?php echo e($address['address']); ?>

                                        </li>
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.Phone')); ?>:&nbsp;</span><?php echo e($address['phone']); ?>

                                        </li>
                                    </ul>
                                <?php else: ?>
                                    <ul class="list-unstyled font-size-sm">
                                        <li>
                                            <span class="text-muted"><?php echo e(trans('messages.Client')); ?>:&nbsp;</span>
                                            <?php echo e(auth('customer')->user()->f_name); ?>

                                        </li>
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.address')); ?>:&nbsp;</span><?php echo e($data['shipping_address']); ?>

                                        </li>
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.Phone')); ?>:&nbsp;</span><?php echo e(auth('customer')->user()->phone); ?>

                                        </li>
                                    </ul>
                                <?php endif; ?>
                            </div>
                            <div class="col-sm-6">
                                <h4 class="h6"><?php echo e(trans('messages.payment_method')); ?>:</h4>
                                <ul class="list-unstyled font-size-sm">
                                    <?php if(session()->has('payment_method') && session('payment_method')=='cash_on_delivery'): ?>
                                        <li><span
                                                class="text-muted"><?php echo e(trans('messages.cash_on_delivery')); ?>&nbsp;</span>
                                        </li>
                                    <?php elseif(session()->has('payment_method') && session('payment_method')=='ssl_commerz_payment'): ?>
                                        <li><span class="text-muted"><?php echo e(trans('messages.SSLCOMMERZ')); ?></span></li>
                                    <?php elseif(session()->has('payment_method') && session('payment_method')=='paypal'): ?>
                                        <li><span class="text-muted"><?php echo e(trans('messages.Paypal')); ?></span></li>
                                    <?php elseif(session()->has('payment_method') && session('payment_method')=='stripe'): ?>
                                        <li><span class="text-muted"><?php echo e(trans('messages.Stripe')); ?></span></li>
                                    <?php elseif(session()->has('payment_method') && session('payment_method')=='paytm'): ?>
                                        <li><span class="text-muted"><?php echo e(trans('messages.Paytm')); ?></span></li>
                                    <?php elseif(session()->has('payment_method') && session('payment_method')=='razor_pay'): ?>
                                        <li><span class="text-muted"><?php echo e(trans('messages.razor_pay')); ?></span></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- Navigation (desktop)-->
                    <div class="row">
                        <div class="col-6">
                            <a class="btn btn-secondary btn-block"
                               href="<?php echo e(route('checkout-payment')); ?>">
                                <i class="czi-arrow-left mt-sm-0 mr-1"></i>
                                <span
                                    class="d-none d-sm-inline"><?php echo e(trans('messages.Back')); ?> <?php echo e(trans('messages.to')); ?> <?php echo e(trans('messages.Payment')); ?>  </span>
                                <span class="d-inline d-sm-none"><?php echo e(trans('messages.Back')); ?></span></a>
                        </div>
                        <div class="col-6">
                            <?php if(session('payment_method')=='cash_on_delivery'): ?>
                                <a class="btn btn-primary btn-block" href="<?php echo e(route('checkout-complete')); ?>">
                                    <span
                                        class="d-none d-sm-inline"><?php echo e(trans('messages.Complete')); ?> <?php echo e(trans('messages.Order')); ?></span>
                                    <span class="d-inline d-sm-none"><?php echo e(trans('messages.Complete')); ?></span>
                                    <i class="czi-arrow-right mt-sm-0 ml-1"></i>
                                </a>
                            <?php elseif(session('payment_method')=='ssl_commerz_payment'): ?>
                                <form action="<?php echo e(url('/pay-ssl')); ?>" method="POST" class="needs-validation">
                                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token"/>
                                    <button class="btn btn-primary btn-block" type="submit">
                                        <span
                                            class="d-none d-sm-inline"><?php echo e(trans('messages.Complete')); ?> <?php echo e(trans('messages.Order')); ?></span>
                                        <span class="d-inline d-sm-none"><?php echo e(trans('messages.Complete')); ?></span>
                                        <i class="czi-arrow-right mt-sm-0 ml-1"></i>
                                    </button>
                                </form>
                            <?php elseif(session('payment_method')=='paypal'): ?>
                                <form class="needs-validation" method="POST" id="payment-form"
                                      action="<?php echo e(route('pay-paypal')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <button class="btn btn-primary btn-block" type="submit">
                                        <span
                                            class="d-none d-sm-inline"><?php echo e(trans('messages.Complete')); ?> <?php echo e(trans('messages.Order')); ?></span>
                                        <span class="d-inline d-sm-none"><?php echo e(trans('messages.Complete')); ?></span>
                                        <i class="czi-arrow-right mt-sm-0 ml-1"></i>
                                    </button>
                                </form>
                            <?php elseif(session('payment_method')=='stripe'): ?>
                                <?php ($config=\App\CPU\Helpers::get_business_settings('stripe')); ?>
                                <form class="needs-validation" method="POST" id="payment-form"
                                      action="<?php echo e(route('pay-stripe')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <button class="btn btn-primary btn-block" type="button"
                                            onclick="$('.stripe-button-el').click()">
                                        <span
                                            class="d-none d-sm-inline"><?php echo e(trans('messages.Complete')); ?> <?php echo e(trans('messages.Order')); ?></span>
                                        <span class="d-inline d-sm-none"><?php echo e(trans('messages.Complete')); ?></span>
                                        <i class="czi-arrow-right mt-sm-0 ml-1"></i>
                                    </button>

                                    <?php ($sub_total=0); ?>
                                    <?php ($total_tax=0); ?>
                                    <?php ($total_shipping_cost=0); ?>
                                    <?php ($total_discount_on_product=0); ?>
                                    <?php if(session()->has('cart') && count( session()->get('cart')) > 0): ?>
                                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php ($sub_total+=$cartItem['price']*$cartItem['quantity']); ?>
                                            <?php ($total_tax+=$cartItem['tax']*$cartItem['quantity']); ?>
                                            <?php ($total_shipping_cost+=$cartItem['shipping_cost']); ?>
                                            <?php ($total_discount_on_product+=$cartItem['discount']*$cartItem['quantity']); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php ($coupon_dis=session()->has('coupon_discount')?session('coupon_discount'):0); ?>

                                    <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                            data-key="<?php echo e($config['published_key']); ?>"
                                            data-amount="<?php echo e(($sub_total+$total_tax+$total_shipping_cost-$coupon_dis-$total_discount_on_product)*100); ?>"
                                            data-name="<?php echo e(auth('customer')->user()->f_name); ?>"
                                            data-description=""
                                            data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                                            data-locale="auto"
                                            data-currency="usd">
                                    </script>
                                </form>
                            <?php elseif(session('payment_method')=='razor_pay'): ?>
                                <?php ($config=\App\CPU\Helpers::get_business_settings('razor_pay')); ?>

                                <?php ($sub_total=0); ?>
                                <?php ($total_tax=0); ?>
                                <?php ($total_shipping_cost=0); ?>
                                <?php ($total_discount_on_product=0); ?>
                                <?php if(session()->has('cart') && count( session()->get('cart')) > 0): ?>
                                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($sub_total+=$cartItem['price']*$cartItem['quantity']); ?>
                                        <?php ($total_tax+=$cartItem['tax']*$cartItem['quantity']); ?>
                                        <?php ($total_shipping_cost+=$cartItem['shipping_cost']); ?>
                                        <?php ($total_discount_on_product+=$cartItem['discount']*$cartItem['quantity']); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php ($coupon_dis=session()->has('coupon_discount')?session('coupon_discount'):0); ?>

                                <form action="<?php echo route('payment-razor'); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <!-- Note that the amount is in paise = 50 INR -->
                                    <!--amount need to be in paisa-->
                                    <script src="https://checkout.razorpay.com/v1/checkout.js"
                                            data-key="<?php echo e(\Illuminate\Support\Facades\Config::get('razor.razor_key')); ?>"
                                            data-amount="<?php echo e(($sub_total+$total_tax+$total_shipping_cost-$coupon_dis-$total_discount_on_product)*100); ?>"
                                            data-buttontext="Pay <?php echo e(($sub_total+$total_tax+$total_shipping_cost-$coupon_dis-$total_discount_on_product)*100); ?> INR"
                                            data-name="<?php echo e(\App\Model\BusinessSetting::where(['type'=>'company_name'])->first()->value); ?>"
                                            data-description=""
                                            data-image="<?php echo e(asset('storage/app/public/company/'.\App\Model\BusinessSetting::where(['type'=>'company_web_logo'])->first()->value)); ?>"
                                            data-prefill.name="<?php echo e(auth('customer')->user()->f_name); ?>"
                                            data-prefill.email="<?php echo e(auth('customer')->user()->email); ?>"
                                            data-theme.color="#ff7529">
                                    </script>
                                </form>

                                <button class="btn btn-primary btn-block" type="button"
                                        onclick="$('.razorpay-payment-button').click()">
                                    <i class="czi-card"></i> Pay Now
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Sidebar-->
            <?php echo $__env->make('web-views.partials._order-summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    setTimeout(function () {
        $('.stripe-button-el').hide();
        $('.razorpay-payment-button').hide();
    }, 10)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce/resources/views/web-views/checkout-review.blade.php ENDPATH**/ ?>